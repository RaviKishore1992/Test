from fastapi.testclient import TestClient
from main import app

client = TestClient(app)

def test_generate_tokens():
    response = client.post("/generate_tokens", json={"text": "hello world"})
    assert response.status_code == 200
    data = response.json()
    assert data["tokens"] == ["hello", "world"]
    assert len(data["checksum"]) == 64  # SHA-256 hash length

def test_generate_tokens_empty():
    response = client.post("/generate_tokens", json={"text": ""})
    assert response.status_code == 200
    data = response.json()
    assert data["tokens"] == []
    assert len(data["checksum"]) == 64

def test_generate_tokens_missing_field():
    response = client.post("/generate_tokens", json={})
    assert response.status_code == 422  # Unprocessable Entity due to missing field