# Token Generator API

A FastAPI-based API to tokenize input text and generate a checksum.

## Features

- Accepts a POST request with a JSON body containing `text`.
- Returns a list of tokens (split by whitespace) and the SHA-256 checksum of the text.
- Welcome endpoint with a participant-customized message.

## How to Run

1. **Install Dependencies**
   ```bash
   pip install fastapi uvicorn
   ```

2. **Run the Application**
   ```bash
   uvicorn main:app --reload
   ```

3. **API Endpoints**

   - `GET /` - Welcome message.
   - `POST /generate_tokens` - Tokenizes text and returns checksum.

   Example request:
   ```bash
   curl -X POST "http://127.0.0.1:8000/generate_tokens" -H "Content-Type: application/json" -d '{"text": "hello world"}'
   ```

## Running Tests

```bash
pytest test_main.py
```

---

## **API Documentation**

Once the server is running, visit:

- [Swagger UI](http://127.0.0.1:8000/docs)
- [ReDoc](http://127.0.0.1:8000/redoc)