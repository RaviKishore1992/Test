from fastapi import FastAPI
from pydantic import BaseModel
import hashlib

app = FastAPI()

# Welcome message with customized participant name
@app.get("/")
def read_root():
    return {"message": "Welcome to the Token Generator API! Participant: Ravi Kishore"}

# TODO: Create a Pydantic model for incoming requests with a 'text' field.
class TextInput(BaseModel):
    text: str

def generate(text: str) -> str:
    """Generate a checksum (SHA-256 hash) of the input text."""
    return hashlib.sha256(text.encode('utf-8')).hexdigest()

# TODO: Create a FastAPI endpoint that accepts POST, uses TextInput, and returns tokens/checksum.
@app.post("/generate_tokens")
def generate_tokens(input: TextInput):
    """
    Accepts a POST request with JSON body containing 'text', returns a list of tokens and checksum.
    - text: The input string to tokenize and checksum.
    """
    tokens = input.text.split()
    checksum = generate(input.text)
    return {"tokens": tokens, "checksum": checksum}